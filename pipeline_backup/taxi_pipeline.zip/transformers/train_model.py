if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer

from sklearn.linear_model import LinearRegression
from sklearn.feature_extraction import DictVectorizer
from sklearn.metrics import mean_absolute_error, mean_squared_error
from math import sqrt
import pandas as pd


@transformer
def train_model(data):

    df = pd.DataFrame(data)

    dict_vectorizer = DictVectorizer(sparse=True)

    locations = df[['PULocationID', 'DOLocationID']].to_dict(orient='records')

    X = dict_vectorizer.fit_transform(locations)

    y = df['duration']

    model = LinearRegression()
    model.fit(X, y)

    y_pred = model.predict(X)

    mae = mean_absolute_error(y, y_pred)
    mse = mean_squared_error(y, y_pred)
    rmse = sqrt(mse)

    print(f"Model Intercept: {model.intercept_}")
    print(f"MAE: {mae}, MSE: {mse}, RMSE: {rmse}")

    return {
        'model': model,
        'dict_vectorizer': dict_vectorizer,
        'metrics': {
            'mae': mae,
            'mse': mse,
            'rmse': rmse
        }
    }