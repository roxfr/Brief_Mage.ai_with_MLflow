import mlflow
import mlflow.sklearn
import pickle
from datetime import datetime


@data_exporter
def log_model_and_metrics(results):

    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    mlflow.set_tracking_uri("http://mlflow:5000")
    experiment_name = f"mage_experiment_{timestamp}"
    mlflow.set_experiment(experiment_name)

    model = results['model']
    dict_vectorizer = results['dict_vectorizer']
    metrics = results['metrics']

    input_example = [{'PULocationID': 1, 'DOLocationID': 2}]

    input_example_transformed = dict_vectorizer.transform(input_example)

    with mlflow.start_run():
        mlflow.sklearn.log_model(model, "yellow_taxi", input_example=input_example_transformed)
        
        mlflow.log_metric("MAE", metrics['mae'])
        mlflow.log_metric("MSE", metrics['mse'])
        mlflow.log_metric("RMSE", metrics['rmse'])
        
        with open('dict_vectorizer.pkl', 'wb') as f:
            pickle.dump(dict_vectorizer, f)
        mlflow.log_artifact('dict_vectorizer.pkl')

        print(f"Modèle et DictVectorizer loggés dans MLFlow sous le nom 'yellow_taxi'.")
        print(f"Logged metrics - MAE: {metrics['mae']}, MSE: {metrics['mse']}, RMSE: {metrics['rmse']}")